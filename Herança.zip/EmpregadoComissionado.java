package heranca;

public class EmpregadoComissionado {
	
	//Atributos da classe empregado comissionado
	private String primeiroNome;
	private String ultimoNome;
	private String cpf;
	private double vendasBruta;
	private double porcentagemComissao; // 0 at� 1
	
	//declara��o de construtor da classe
    public EmpregadoComissionado(String pNome, String uNome, String cpf, double vendasBruta, double porcentagemComissao) {
    	primeiroNome= pNome;
    	ultimoNome= uNome;
    	this.cpf= cpf;
    	this.vendasBruta= vendasBruta;
    	this.porcentagemComissao= porcentagemComissao;
    }//fim
    
    public void setprimeiroNome(String a) {
    	this.primeiroNome= a;
    }
    
    public String getPrimeiroNome() {
    	return primeiroNome;
    }
    
    public void setUltimoNome(String uNome) {
    	this.ultimoNome= uNome;
    }
    
    public String getUltimoNome() {
    	return ultimoNome;
    }
    
    public void setCpf(String cpf) {
    	this.cpf= cpf;
    }
    
    public String getCpf() {
    	return cpf;
    }
    
    public void setVendasBruta(double venda) {
    	this.vendasBruta= (venda < 0.0)? 0.0 : venda;
    }
     
    public double getVendasBruta() {
    	return vendasBruta;
    }
    
    public void setporcentagemComissao(double pc) {
    	this.porcentagemComissao= (pc < 0.0 || pc > 1.0)? 0.01 : pc;
    }
    
    public double getPorcentagemComissao() {
    	return porcentagemComissao;
    }
    
    public double salario() {
    	double valor= this.getVendasBruta()* this.getPorcentagemComissao();
    	return valor;
    }
    
    public void Detalhes() {
    	System.out.printf(
    			"Primeiro nome: %s\n"
    			+ "Ultimo Nome: %s\n"
    		    + "CPF: %s\n"
    			+"Comiss�o:%.2f\n"
    		    + "Vendas:%.2f\n", this.getPrimeiroNome(), this.getUltimoNome(), this.getCpf(),
    		    this.getPorcentagemComissao(), this.getVendasBruta()
    			);
    }
    
}//fim classe

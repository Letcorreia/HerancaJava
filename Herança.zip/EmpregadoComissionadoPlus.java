package heranca;

public class EmpregadoComissionadoPlus extends EmpregadoComissionado {
	private double salarioBase;
	
	public EmpregadoComissionadoPlus (double salarioBase, String pNome, String uNome, String cpf,
			double vendasBruta, double porcentagemComissao) {
		super(pNome, uNome, cpf, vendasBruta, porcentagemComissao);
		this.salarioBase= salarioBase;
	}//fim construtor
	
	
	public void setSalarioBase(double v) {
		this.salarioBase= v;
	}
	
	public double getSalarioBase() {
		return salarioBase;
	}
	
	
	public double salario() {
		double novoSalario = this.getSalarioBase() + super.salario();
		return novoSalario;
	}//fim salario
	
	public void Detalhes() {
		super.Detalhes();
		System.out.printf("Salario Base:%2f\n", this.getSalarioBase());
	}

}//fim classe
